<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
</head>
<body>
  <h1>登入</h1>
  <form action="login.php" method="post">
    <label for="username">Username:</label>
    <input type="text" name="username" id="username"><br><br>
    <label for="password">Password:</label>
    <input type="password" name="password" id="password"><br><br>
    <input type="submit" value="Login">
  </form>

  <h2>註冊</h2>
  <form action="register.php" method="post">
    
    <input type="submit" value="Register">
  </form>

  <?php
  // 處理登陸請求
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // 連接資料庫
    $servername = "localhost";
    $dbusername = "root";
    $dbpassword = "lkl900513";
    $dbname = "cloud";

    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // 搜尋使用者資料
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      header("Location: home.php");
      exit();
    } else {
      echo "Invalid username or password.";
    }

    $conn->close();
  }
  ?>
</body>
</html>
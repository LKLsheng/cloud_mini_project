<?php
if(isset($_POST['keyword'])) {
  $url = 'https://mojim.com/' . $_POST['keyword'] . '.html?t4';

  // 使用 curl 函數來獲取關鍵詞相關的 HTML 頁面
  //$url = 'https://mojim.com/'.$keyword.'.html?t4';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $html = curl_exec($ch);
  curl_close($ch);

  $dom = new DOMDocument();
  @$dom->loadHTML($html);
  
  $dd_elements = $dom->getElementsByTagName('dd');
  foreach ($dd_elements as $dd_element) {
    // 查找 class 為 'mxsh_dd1' 和 'mxsh_dd2' 的 dd 元素
    if ($dd_element->getAttribute('class') == 'mxsh_dd1' || $dd_element->getAttribute('class') == 'mxsh_dd2') {
      // 查找 dd 元素下的 span 元素
      $span_elements = $dd_element->getElementsByTagName('span');
      foreach ($span_elements as $span_element) {
        /*if ($span_element->getAttribute('class') == 'mxsh_ss1' || $span_element->getAttribute('class') == 'mxsh_ss2' || $span_element->getAttribute('class') == 'mxsh_ss3') {
          echo $span_element->textContent . '<br>';
          $a_elements = $span_element ->getElementsByTagName('a');
          foreach ($a_elements as $a_element) {
            if ($span_element->getAttribute('class') == 'mxsh_ss3'){
              $var = $a_element->getAttribute('href');
              echo '<form action="page2.php" method="post">';
              echo '<input type="hidden" name="var" value="' . $var . '">';
              echo '<button type="submit">Go to target page</button>';
              echo '</form>';
            }
          }
        }*/
        if ($span_element->getAttribute('class') == 'mxsh_ss1'){
          echo $span_element->textContent . '<br>';
        }
        else if ($span_element->getAttribute('class') == 'mxsh_ss2'){
          echo "歌名：" .  $span_element->textContent . '<br>';
        }
        else if ($span_element->getAttribute('class') == 'mxsh_ss3'){
          echo "歌詞：" .  $span_element->textContent . '<br>';
        }
        $a_elements = $span_element ->getElementsByTagName('a');
        foreach ($a_elements as $a_element) {
          if ($span_element->getAttribute('class') == 'mxsh_ss3'){
            $var = $a_element->getAttribute('href');
            echo '<form action="page2.php" method="post">';
            echo '<input type="hidden" name="var" value="' . $var . '">';
            echo '<button type="submit">Go to target page</button>';
            echo '</form>';
          }
        }

      }
    }
  }
  
}
?>
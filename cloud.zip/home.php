<form method="post" action="test.php">
  <label for="keyword">請輸入關鍵詞：</label>
  <input type="text" name="keyword" placeholder="請輸入關鍵詞">
  <input type="submit" value="提交">
</form>
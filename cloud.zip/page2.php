<?php
	if(isset($_POST['var'])) {
		$url = 'https://mojim.com' . $_POST['var'];
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$html = curl_exec($ch);
		curl_close($ch);
		
		$dom = new DOMDocument();
		@$dom->loadHTML($html);

		$h1_elements = $dom->getElementsByTagName('h1');
		foreach ($h1_elements as $h1_element){
            $singer = "歌手：" .  $h1_element->textContent . PHP_EOL;
			echo "歌手：" .  $h1_element->textContent . '<br>';
		}
		
		$dl_elements = $dom->getElementsByTagName('dl');
		foreach ($dl_elements as $dl_element) {
			if ($dl_element->getAttribute('class') == 'fsZx1'){
				$dt_elements = $dl_element->getElementsByTagName('dt');
				//echo $dl_element->textContent . '<br>';
				foreach ($dt_elements as $dt_element){
                    $song_name = "歌曲：" . $dt_element->textContent . PHP_EOL;
					echo "歌曲：" . $dt_element->textContent . '<br>';
				}
				$dd_elements = $dl_element->getElementsByTagName('dd');
                $lyrics = '';
				foreach ($dd_elements as $dd_element){
					$brs = $dd_element->getElementsByTagName('br');
					$previousSibling = null;
					foreach ($brs as $br) {
						$textNode = $br->nextSibling;
						while ($textNode instanceof DOMText) {
                            $lyrics .= $textNode->nodeValue;
							echo $textNode->nodeValue;
							$textNode = $textNode->nextSibling;
						}
                        $lyrics .= PHP_EOL;
						echo '<br>';
					}
					/*$textNode = $dd->lastChild;
					while ($textNode instanceof DOMText) {
						echo $textNode->nodeValue;
						$textNode = $textNode->previousSibling;
					}
					echo '<br>';*/
				}
			}
		}
        
            $var = $singer . $song_name . $lyrics;
            echo '<form action="page3.php" method="post">';
            echo '<input type="hidden" name="var" value="' . $var . '">';
            echo '<button type="submit">work</button>';
            echo '</form>';
          		
					
		//echo $html;
	}
?>
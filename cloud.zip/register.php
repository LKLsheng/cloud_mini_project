<!DOCTYPE html>
<html>
<head>
  <title>Register Page</title>
</head>
<body>
  <h1>Register</h1>
  <form action="register.php" method="post">
    <label for="username">Username:</label>
    <input type="text" name="username" id="username"><br><br>
    <label for="password">Password:</label>
    <input type="password" name="password" id="password"><br><br>
    <input type="submit" value="Register">
  </form>

  <?php
  // 處理註冊請求
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // 連接資料庫
    $servername = "localhost";
    $dbusername = "root";
    $dbpassword = "lkl900513";
    $dbname = "cloud";

    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // 檢查使用者名稱是否已存在
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      // 使用者名稱已存在
      echo "Username already exists.";
    } else {
      // 新增使用者
      $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
      if ($conn->query($sql) === TRUE) {
        // 註冊成功，跳轉到 login.php
        header("Location: login.php");
        exit();
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
    }

    $conn->close();
  }
  ?>
</body>
</html>
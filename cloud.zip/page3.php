<?php
// Start or resume the session
session_start();

if (!isset($_SESSION['todo_list'])) {
  $_SESSION['todo_list'] = array();
}

if (isset($_POST['var'])) {
  $data = $_POST['var'];
  $a = explode(PHP_EOL , $data);
  $singer = explode('：' , $a[0]);
  $song = explode('：' , $a[1]);
  $filename = $singer[1] . '_' . $song[1] . '.txt';  
  // Check if the item already exists in the to-do list
  $exists = false;
  foreach ($_SESSION['todo_list'] as $item) {
    if ($item['name'] == $filename && $item['data'] == $data) {
      $exists = true;
      break;
    }
  }
  // If the item does not exist, add it to the to-do list
  if (!$exists) {
    $_SESSION['todo_list'][] = array(
    'name' => $filename,
    'data' => $data,
    'status' => 'queue'
    );
  }
}

// Check if an item was submitted for deletion from the to-do list
if (isset($_POST['delete_item'])) {
  // Remove the specified item from the to-do list array
  unset($_SESSION['todo_list'][$_POST['delete_item']]);
  // Reset the array keys to ensure they are contiguous
  $_SESSION['todo_list'] = array_values($_SESSION['todo_list']);
}

// Check if an item was submitted for download as a text file
if (isset($_POST['download'])) {
  $index = $_POST['download'];
  //$_SESSION['todo_list'][$index]['status'] = 'downloading';
  global $data;
  global $filename;
  @file_put_contents($filename, $data);
  // Set the content type header to plain text
  header('Content-type: text/plain');
  // Set the content disposition header to force download
  header('Content-disposition: attachment; filename="'.$_SESSION['todo_list'][$index]['name']);
  // Output the to-do list as plain text
  //sleep(30);
  echo $_SESSION['todo_list'][$index]['data'];
  // Update the status to "finish"
  $_SESSION['todo_list'][$index]['status'] = 'finish';
  
  // Exit to prevent any further output
  exit;
  
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>下載列</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
<body>
  <h1>下載列</h1>
  <!--<form method="post">
    <label for="add_item">New item:</label>
    <input type="text" name="var" id="add_item">
    <button type="submit">Add</button>
  </form>-->
  <form method="post">
    <table>
      <thead>
        <tr>
          <th>Task</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Generate an HTML table of the to-do items
        foreach ($_SESSION['todo_list'] as $key => $item) {
          echo '<tr>';
          echo '<td>' . htmlspecialchars($item['name']) . '</td>';
          echo '<td>' . htmlspecialchars($item['status']) . '</td>';
          echo '<td>';
          if ($item['status'] == 'queue') {
            echo '<button onclick="reloadPageAfter20s()" type="submit" name="download" value="' . $key . '">Download</button> ';
          }
          echo '<button type="submit" name="delete_item" value="' . $key . '">Delete</button></td>';
          echo '</tr>';
        }
        ?>
      </tbody>
    </table>
  </form>
  <form method="post" action="home.php">
  <input type="submit" value="首頁">
</form>
<script>
  function reloadPageAfter20s() {
    setTimeout(function() {
      location.reload();
    }, 3000);
  }
</script>
</body>
</html>